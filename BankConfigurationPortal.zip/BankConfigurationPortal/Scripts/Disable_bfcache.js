// This event listener is in place to handle the unload event.
window.addEventListener("unload", function () { });
